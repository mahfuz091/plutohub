import React from "react";

// Define the props types for the Filter component
interface FilterProps {
  categories: string[];
  onSelectCategory: (category: string) => void;
}

const Filter: React.FC<FilterProps> = ({ categories, onSelectCategory }) => {
  return (
    <div className='filter'>
      <button onClick={() => onSelectCategory("")}>All</button>
      {categories.map((category) => (
        <button key={category} onClick={() => onSelectCategory(category)}>
          {category}
        </button>
      ))}
    </div>
  );
};

export default Filter;

import React, { useEffect, useState } from "react";

// Define the type for each item
interface ItemProps {
  item: {
    id: number;
    name: string;
    description: string;
    category: string;
  };
}

const Item: React.FC<ItemProps> = ({ item }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100); // Small delay before animation starts
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`item ${isVisible ? "appear" : ""}`}>
      <h3>{item.name}</h3>
      <p>{item.description}</p>
      <span>{item.category}</span>
    </div>
  );
};

export default Item;

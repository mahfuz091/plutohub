"use client";
import React, { useState } from "react";

import Masonry from "react-masonry-css"; // Import Masonry grid
import Filter from "./Filter";
import Item from "./Item";

// Define the type for each item
type ItemType = {
  id: number;
  name: string;
  description: string;
  category: string;
};

const Blogs: React.FC = () => {
  // Sample data for items
  const items: ItemType[] = [
    {
      id: 1,
      name: "Item 1",
      description: "This is item 1",
      category: "Category 1",
    },
    {
      id: 2,
      name: "Item 2",
      description: "This is item 2",
      category: "Category 2",
    },
    {
      id: 3,
      name: "Item 3",
      description: "This is item 3",
      category: "Category 1",
    },
    {
      id: 4,
      name: "Item 4",
      description: "This is item 4",
      category: "Category 3",
    },
    {
      id: 5,
      name: "Item 5",
      description: "This is item 5",
      category: "Category 2",
    },
    {
      id: 6,
      name: "Item 6",
      description: "This is item 6",
      category: "Category 1",
    },
    // Add more items here
  ];

  // Categories for the filter
  const categories: string[] = ["Category 1", "Category 2", "Category 3"];

  // State to manage the filtered items
  const [filteredItems, setFilteredItems] = useState<ItemType[]>(items);

  // Handle category selection for filtering
  const handleSelectCategory = (category: string) => {
    if (category === "") {
      setFilteredItems(items);
    } else {
      const filtered = items.filter((item) => item.category === category);
      setFilteredItems(filtered);
    }
  };

  return (
    <div className='app'>
      <div className='container'>
        <h1>Isotope-like Filter with Animations</h1>
        <Filter
          categories={categories}
          onSelectCategory={handleSelectCategory}
        />

        {/* Use Masonry for a grid layout */}
        <Masonry
          breakpointCols={{
            320: 1, // 1 column on very small screens
            480: 2, // 2 columns on mobile devices
            768: 3, // 3 columns on tablets
            1024: 3, // 3 columns on larger screens
          }}
          className='my-masonry-grid'
          columnClassName='my-masonry-grid_column'
        >
          {filteredItems.map((item) => (
            <Item key={item.id} item={item} />
          ))}
        </Masonry>
      </div>
    </div>
  );
};

export default Blogs;

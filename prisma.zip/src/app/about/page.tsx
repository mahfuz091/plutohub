import AboutUs from "../../Components/AboutUs/AboutUs";


export default function AboutPage() {
  return <AboutUs />;
}

"use server";

import { prisma } from "@/lib/prisma"; // adjust import if your prisma client path differs
import bcrypt from "bcryptjs";
import { signIn, signOut, auth } from "@/auth";
import { revalidatePath } from "next/cache";
/** ---------- Types ---------- */
type ActionResult =
  | { success: true; msg: string }
  | { success: false; msg: string };

type LoginResult =
  | { success: true; msg: string }
  | { success: false; msg: string };

export const registerUser = async (
  _prevState: unknown,
  formData: FormData
): Promise<ActionResult> => {
  try {
    const name = formData.get("name");

    const email = formData.get("email");
    const password = formData.get("password");

    if (!name || !email || !password) {
      return { success: false, msg: "Required fields are missing" };
    }

    const existing = await prisma.user.findUnique({
      where: { email: email as string },
    });
    if (existing) {
      return { success: false, msg: "User already exists" };
    }

    const hashedPass = await bcrypt.hash(password as string, 10);

    const created = await prisma.user.create({
      data: {
        name: name as string,
        email: email as string,

        password: hashedPass,
      },
      select: { id: true, name: true },
    });

    return { success: true, msg: `${created.name} Welcome` };
  } catch (err) {
    console.error("registerUser error:", err);
    return { success: false, msg: "Something went wrong" };
  }
};

/** ---------- Login ---------- */
export const loginUser = async (
  _prevState: unknown,
  formData: FormData
): Promise<LoginResult> => {
  try {
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;

    if (!email || !password) {
      return { success: false, msg: "Email and password are required" };
    }

    // Include the hashed password field name that your Prisma model uses
    const user = await prisma.user.findUnique({
      where: { email: email as string },
      select: { id: true, email: true, password: true }, // use passwordHash if that's your column
    });

    if (!user) {
      return { success: false, msg: "User doesnt exist, Please Register." };
    }

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) {
      return { success: false, msg: "Password didnt match" };
    }

    // NextAuth will handle redirect; it may throw—caught below
    await signIn("credentials", {
      redirectTo: "/dashboard",
      email,
      password,
    });

    return { success: true, msg: "Logged in" };
  } catch (err: any) {
    const message =
      typeof err?.message === "string" ? err.message : "Login failed";
    console.error("loginUser error:", err);
    return { success: false, msg: message };
  }
};

/** ---------- Logout ---------- */
export const logOut = async (): Promise<void> => {
  try {
    await signOut();
  } catch (err) {
    console.error("logOut error:", err);
  }
};

/** ---------- List Users (safe selection) ---------- */
export const userList = async () => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true,

        name: true,
        email: true,
        createdAt: true, // remove if your schema doesn't have it
      },
      orderBy: { createdAt: "desc" }, // adjust or remove
    });
    return users;
  } catch (err) {
    console.error("userList error:", err);
    return [];
  }
};

/** ---------- Update Profile ---------- */
/**
 * This version assumes your User model has these nullable columns:
 * fathersname, mothersname, phone, address, hobby, profession
 * If you keep them in a related `Profile` model, replace the update call with:
 * prisma.user.update({ where: { id }, data: { profile: { upsert: { ... }}}})
 */

/** ---------- Get User Profile (safe selection) ---------- */
export const getUserProfile = async () => {
  try {
    const session = await auth();
    const email = session?.user?.email;
    if (!email) return { user: null };

    const user = await prisma.user.findUnique({
      where: { email },
      select: {
        id: true,
        name: true,
        email: true,
        createdAt: true, // remove if not present
      },
    });

    return { user };
  } catch (err) {
    console.error("getUserProfile error:", err);
    return { user: null };
  }
};

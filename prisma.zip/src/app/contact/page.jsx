import ContactUs from "../../Components/ContactUs/ContactUs";





export default function ContactPage() {
  return <ContactUs/>;
}

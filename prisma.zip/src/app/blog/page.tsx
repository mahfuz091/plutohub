import React from "react";
import BlogPage from "../../Components/BlogPage/BlogPage";

const page = () => {
  return <BlogPage />;
};

export default page;
